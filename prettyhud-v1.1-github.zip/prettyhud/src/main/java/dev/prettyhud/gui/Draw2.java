package dev.prettyhud.gui;

import net.minecraft.client.gui.GuiGraphics;

final class Draw2 {
    private Draw2() {}

    /** Скруглённая «таблетка»: радиус 2 px. */
    static void pill(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x + 2, y, x + w - 2, y + h, argb);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, argb);
        g.fill(x, y + 2, x + w, y + h - 2, argb);
    }
}
