package dev.prettyhud.gui;

import dev.prettyhud.config.Theme;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Элементы меню: заголовок секции, переключатель, ползунок, выбор из списка, кнопка. */
abstract class Ctl {
    int h = 18;

    abstract void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t);

    /** @return true, если элемент перехватил клик и дальше его можно тянуть мышью (ползунок). */
    boolean click(int x, int y, int w, int mx, int my) { return false; }

    void drag(int x, int w, int mx) {}

    static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ---------------------------------------------------------------

    static final class Section extends Ctl {
        final String title;
        Section(String title) { this.title = title; this.h = 20; }

        @Override void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t) {
            g.drawString(font, title.toUpperCase(), x, y + 8, Theme.argb(0x8A93A8, 1f), false);
            g.fill(x, y + 18, x + w, y + 19, Theme.argb(0xFFFFFF, 0.07f));
        }
    }

    static final class Toggle extends Ctl {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label; this.get = get; this.set = set;
        }

        @Override void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t) {
            if (in(mx, my, x, y, w, h)) g.fill(x - 2, y, x + w + 2, y + h, Theme.argb(0xFFFFFF, 0.04f));
            g.drawString(font, label, x, y + 5, Theme.argb(0xFFFFFF, 0.95f), false);
            boolean on = get.getAsBoolean();
            int sx = x + w - 28, sy = y + 3;
            Draw2.pill(g, sx, sy, 26, 12, on ? Theme.argb(t.primary(), 1f) : Theme.argb(0x2A3042, 1f));
            int kx = on ? sx + 15 : sx + 1;
            g.fill(kx, sy + 1, kx + 10, sy + 11, Theme.argb(0xFFFFFF, 1f));
        }

        @Override boolean click(int x, int y, int w, int mx, int my) {
            if (!in(mx, my, x, y, w, h)) return false;
            set.accept(!get.getAsBoolean());
            return false;
        }
    }

    static final class Slider extends Ctl {
        final String label, fmt;
        final float min, max;
        final Supplier<Float> get;
        final Consumer<Float> set;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label; this.min = min; this.max = max; this.fmt = fmt; this.get = get; this.set = set;
        }

        private int trackX(int x, int w) { return x + w - 140; }

        @Override void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t) {
            g.drawString(font, label, x, y + 5, Theme.argb(0xFFFFFF, 0.95f), false);
            int tx = trackX(x, w), tw = 92;
            float f = (get.get() - min) / (max - min);
            g.fill(tx, y + 8, tx + tw, y + 10, Theme.argb(0x2A3042, 1f));
            g.fill(tx, y + 8, tx + Math.round(tw * f), y + 10, Theme.argb(t.primary(), 1f));
            int kx = tx + Math.round(tw * f);
            g.fill(kx - 2, y + 5, kx + 2, y + 13, Theme.argb(0xFFFFFF, 1f));
            String v = String.format(fmt, get.get());
            g.drawString(font, v, x + w - font.width(v), y + 5, Theme.argb(0x9AA3B5, 1f), false);
        }

        @Override boolean click(int x, int y, int w, int mx, int my) {
            int tx = trackX(x, w);
            if (!in(mx, my, tx - 4, y, 100, h)) return false;
            drag(x, w, mx);
            return true;
        }

        @Override void drag(int x, int w, int mx) {
            int tx = trackX(x, w), tw = 92;
            float f = Math.max(0f, Math.min(1f, (mx - tx) / (float) tw));
            set.accept(min + f * (max - min));
        }
    }

    static final class Cycle extends Ctl {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label; this.options = options; this.get = get; this.set = set;
        }

        @Override void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t) {
            g.drawString(font, label, x, y + 5, Theme.argb(0xFFFFFF, 0.95f), false);
            String v = options[Math.floorMod(get.getAsInt(), options.length)];
            int bw = font.width(v) + 14;
            int bx = x + w - bw;
            Draw2.pill(g, bx, y + 2, bw, 14, in(mx, my, bx, y + 2, bw, 14) ? Theme.argb(0x2A3042, 1f) : Theme.argb(0x1B2030, 1f));
            g.drawString(font, v, bx + 7, y + 5, Theme.argb(t.secondary(), 1f), false);
        }

        @Override boolean click(int x, int y, int w, int mx, int my) {
            if (!in(mx, my, x, y, w, h)) return false;
            set.accept((get.getAsInt() + 1) % options.length);
            return false;
        }
    }

    static final class Button extends Ctl {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) { this.label = label; this.action = action; this.h = 22; }

        @Override void render(GuiGraphics g, Font font, int x, int y, int w, int mx, int my, Theme t) {
            boolean hov = in(mx, my, x, y + 2, w, 18);
            int c1 = Theme.argb(t.primary(), hov ? 1f : 0.88f);
            Draw2.pill(g, x, y + 2, w, 18, c1);
            g.drawString(font, label, x + (w - font.width(label)) / 2, y + 7, Theme.argb(0xFFFFFF, 1f), false);
        }

        @Override boolean click(int x, int y, int w, int mx, int my) {
            if (!in(mx, my, x, y + 2, w, 18)) return false;
            action.run();
            return false;
        }
    }
}
