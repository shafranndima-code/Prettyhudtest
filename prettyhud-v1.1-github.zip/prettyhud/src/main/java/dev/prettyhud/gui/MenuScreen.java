package dev.prettyhud.gui;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/** Меню настроек: слева вкладки, справа настройки. Тёмный стиль с акцентом выбранной темы. */
public class MenuScreen extends Screen {
    private static final int W = 440, H = 270, SIDE = 112, PAD = 14;
    private static final String[] TABS = {"Интерфейс", "Эффекты", "Темы"};

    private int tab = 0;
    private float scroll = 0;
    private final List<List<Ctl>> pages = new ArrayList<>();
    private Ctl dragging = null;
    private int dragX, dragW;
    private int x0, y0;

    public MenuScreen() {
        super(Component.literal("Pretty HUD"));
        buildPages();
    }

    private void buildPages() {
        HudConfig c = HudConfig.get();

        List<Ctl> ui = new ArrayList<>();
        ui.add(new Ctl.Section("Общие настройки"));
        ui.add(new Ctl.Toggle("Тени", () -> c.shadows, v -> c.shadows = v));
        ui.add(new Ctl.Toggle("Свечение", () -> c.glow, v -> c.glow = v));
        ui.add(new Ctl.Slider("Прозрачность", 0.2f, 1f, "%.2f", () -> c.opacity, v -> c.opacity = v));
        ui.add(new Ctl.Slider("Масштаб HUD", 0.6f, 1.6f, "%.2fx", () -> c.scale, v -> c.scale = v));
        ui.add(new Ctl.Section("Зелья"));
        ui.add(new Ctl.Toggle("Показывать плашку зелий", () -> c.potions.enabled, v -> c.potions.enabled = v));
        ui.add(new Ctl.Slider("Предупреждать за (сек)", 3, 30, "%.0f", () -> (float) c.potionWarnSeconds, v -> c.potionWarnSeconds = Math.round(v)));
        ui.add(new Ctl.Section("FPS и пинг"));
        ui.add(new Ctl.Toggle("Показывать плашку", () -> c.stats.enabled, v -> c.stats.enabled = v));
        ui.add(new Ctl.Toggle("FPS", () -> c.statsShowFps, v -> c.statsShowFps = v));
        ui.add(new Ctl.Toggle("Пинг", () -> c.statsShowPing, v -> c.statsShowPing = v));
        ui.add(new Ctl.Section("Броня"));
        ui.add(new Ctl.Toggle("Показывать броню", () -> c.armor.enabled, v -> c.armor.enabled = v));
        ui.add(new Ctl.Toggle("Прочность числом", () -> c.armorShowDurability, v -> c.armorShowDurability = v));
        ui.add(new Ctl.Button("Редактор HUD (перетаскивание)", () -> minecraft.setScreen(new HudEditorScreen(this))));
        pages.add(ui);

        List<Ctl> fx = new ArrayList<>();
        fx.add(new Ctl.Section("Нимб"));
        fx.add(new Ctl.Toggle("Нимб над головой (только 3-е лицо)", () -> c.halo, v -> c.halo = v));
        fx.add(new Ctl.Toggle("Нимб у других игроков", () -> c.haloForOthers, v -> c.haloForOthers = v));
        fx.add(new Ctl.Toggle("Искорки над нимбом", () -> c.haloSparkles, v -> c.haloSparkles = v));
        fx.add(new Ctl.Slider("Высота", 0.1f, 0.9f, "%.2f", () -> c.haloHeight, v -> c.haloHeight = v));
        fx.add(new Ctl.Slider("Радиус", 0.15f, 0.6f, "%.2f", () -> c.haloRadius, v -> c.haloRadius = v));
        fx.add(new Ctl.Section("Частицы в небе"));
        fx.add(new Ctl.Toggle("Включить", () -> c.skyParticles, v -> c.skyParticles = v));
        fx.add(new Ctl.Cycle("Вид", new String[]{"Звёзды", "Снег", "Светлячки", "Цвет темы", "Падающие звёзды"}, () -> c.skyParticleType, v -> c.skyParticleType = v));
        fx.add(new Ctl.Slider("Плотность", 1, 10, "%.0f", () -> (float) c.skyParticleDensity, v -> c.skyParticleDensity = Math.round(v)));
        fx.add(new Ctl.Slider("Высота", 8, 40, "%.0f", () -> (float) c.skyParticleHeight, v -> c.skyParticleHeight = Math.round(v)));
        fx.add(new Ctl.Section("Подсветка цели"));
        fx.add(new Ctl.Toggle("Обводка цели под прицелом", () -> c.targetOutline, v -> c.targetOutline = v));
        fx.add(new Ctl.Toggle("Только игроки", () -> c.targetOutlineOnlyPlayers, v -> c.targetOutlineOnlyPlayers = v));
        fx.add(new Ctl.Toggle("Плавная смена цвета", () -> c.targetPulse, v -> c.targetPulse = v));
        fx.add(new Ctl.Toggle("Кольцо под целью", () -> c.targetRing, v -> c.targetRing = v));
        pages.add(fx);

        pages.add(new ArrayList<>()); // «Темы» рисуются отдельно
    }

    // -------------------------------------------------------------- рендер

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        HudConfig c = HudConfig.get();
        Theme t = c.theme();
        x0 = (width - W) / 2;
        y0 = (height - H) / 2;

        g.fill(0, 0, width, height, Theme.argb(0x000000, 0.45f));
        Draw2.pill(g, x0 - 2, y0 - 2, W + 4, H + 4, Theme.argb(t.primary(), 0.12f));
        Draw2.pill(g, x0, y0, W, H, Theme.argb(0x0B0F1A, 0.96f));
        g.fill(x0 + SIDE, y0 + 10, x0 + SIDE + 1, y0 + H - 10, Theme.argb(0xFFFFFF, 0.06f));

        // шапка
        g.fill(x0 + PAD, y0 + 14, x0 + PAD + 4, y0 + 30, Theme.argb(t.primary(), 1f));
        g.drawString(font, "Pretty", x0 + PAD + 9, y0 + 15, Theme.argb(0xFFFFFF, 1f), false);
        g.drawString(font, "HUD", x0 + PAD + 9 + font.width("Pretty "), y0 + 15, Theme.argb(t.primary(), 1f), false);
        g.drawString(font, "v1.0", x0 + PAD + 9, y0 + 25, Theme.argb(0x6B7388, 1f), false);

        // вкладки
        for (int i = 0; i < TABS.length; i++) {
            int ty = y0 + 52 + i * 24;
            boolean sel = i == tab;
            boolean hov = Ctl.in(mx, my, x0 + 8, ty, SIDE - 16, 20);
            if (sel) Draw2.pill(g, x0 + 8, ty, SIDE - 16, 20, Theme.argb(0xFFFFFF, 0.07f));
            else if (hov) Draw2.pill(g, x0 + 8, ty, SIDE - 16, 20, Theme.argb(0xFFFFFF, 0.03f));
            if (sel) g.fill(x0 + 8, ty + 3, x0 + 10, ty + 17, Theme.argb(t.primary(), 1f));
            g.drawString(font, TABS[i], x0 + 18, ty + 6, Theme.argb(0xFFFFFF, sel ? 1f : 0.65f), false);
        }
        g.drawString(font, "Только визуал.", x0 + 12, y0 + H - 26, Theme.argb(0x6B7388, 1f), false);
        g.drawString(font, "Без читов.", x0 + 12, y0 + H - 16, Theme.argb(0x6B7388, 1f), false);

        int cx = x0 + SIDE + PAD, cw = W - SIDE - PAD * 2;
        int top = y0 + 12, bottom = y0 + H - 12;
        g.enableScissor(cx - 4, top, cx + cw + 4, bottom);
        if (tab == 2) renderThemes(g, cx, top, cw, mx, my, t, c);
        else renderList(g, cx, top, cw, bottom, mx, my, t);
        g.disableScissor();
    }

    private int contentHeight(List<Ctl> list) {
        int h = 0;
        for (Ctl ctl : list) h += ctl.h;
        return h;
    }

    private void renderList(GuiGraphics g, int cx, int top, int cw, int bottom, int mx, int my, Theme t) {
        List<Ctl> list = pages.get(tab);
        float maxScroll = Math.max(0, contentHeight(list) - (bottom - top));
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        int y = top - Math.round(scroll);
        for (Ctl ctl : list) {
            if (y + ctl.h > top - 20 && y < bottom + 20) ctl.render(g, font, cx, y, cw, mx, my, t);
            y += ctl.h;
        }
        if (maxScroll > 0) { // полоса прокрутки
            int bh = Math.max(16, Math.round((bottom - top) * (bottom - top) / (float) contentHeight(list)));
            int by = top + Math.round((scroll / maxScroll) * (bottom - top - bh));
            g.fill(cx + cw + 6, by, cx + cw + 8, by + bh, Theme.argb(t.primary(), 0.8f));
        }
    }

    private void renderThemes(GuiGraphics g, int cx, int top, int cw, int mx, int my, Theme t, HudConfig c) {
        g.drawString(font, "ТЕМЫ", cx, top + 4, Theme.argb(0x8A93A8, 1f), false);
        int colW = (cw - 8) / 2;
        for (int i = 0; i < Theme.PRESETS.length; i++) {
            Theme p = Theme.PRESETS[i];
            int bx = cx + (i % 2) * (colW + 8);
            int by = top + 18 + (i / 2) * 25;
            boolean active = !c.useCustomTheme && c.themeIndex == i;
            boolean hov = Ctl.in(mx, my, bx, by, colW, 22);
            Draw2.pill(g, bx, by, colW, 22, Theme.argb(active ? p.primary() : 0xFFFFFF, active ? 0.18f : (hov ? 0.07f : 0.04f)));
            g.fill(bx + 4, by + 4, bx + 18, by + 18, Theme.argb(p.primary(), 1f));
            g.fill(bx + 11, by + 4, bx + 18, by + 18, Theme.argb(p.secondary(), 1f));
            g.drawString(font, p.name(), bx + 24, by + 3, Theme.argb(0xFFFFFF, 1f), false);
            g.drawString(font, font.plainSubstrByWidth(p.description(), colW - 28), bx + 24, by + 12, Theme.argb(0x7B8498, 1f), false);
        }
        int cy = top + 18 + (Theme.PRESETS.length / 2) * 25 + 6;
        g.drawString(font, "СВОЯ ТЕМА", cx, cy, Theme.argb(0x8A93A8, 1f), false);
        hueBar(g, cx, cy + 12, cw, "Цвет 1", c.customColor1, mx, my, c.useCustomTheme);
        hueBar(g, cx, cy + 30, cw, "Цвет 2", c.customColor2, mx, my, c.useCustomTheme);
    }

    private void hueBar(GuiGraphics g, int x, int y, int w, String label, int rgb, int mx, int my, boolean active) {
        g.drawString(font, label, x, y + 2, Theme.argb(0xFFFFFF, 0.9f), false);
        int bx = x + 50, bw = w - 50 - 24;
        for (int i = 0; i < bw; i++) {
            int col = Color.HSBtoRGB(i / (float) bw, 0.75f, 1f) & 0xFFFFFF;
            g.fill(bx + i, y, bx + i + 1, y + 12, Theme.argb(col, 1f));
        }
        float[] hsb = Color.RGBtoHSB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, null);
        int kx = bx + Math.round(hsb[0] * (bw - 1));
        g.fill(kx - 1, y - 2, kx + 2, y + 14, Theme.argb(0xFFFFFF, 1f));
        g.fill(x + w - 18, y, x + w, y + 12, Theme.argb(rgb, 1f));
    }

    // -------------------------------------------------------------- ввод

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        int mx = (int) event.x(), my = (int) event.y();
        HudConfig c = HudConfig.get();
        for (int i = 0; i < TABS.length; i++) {
            if (Ctl.in(mx, my, x0 + 8, y0 + 52 + i * 24, SIDE - 16, 20)) {
                tab = i; scroll = 0; return true;
            }
        }
        int cx = x0 + SIDE + PAD, cw = W - SIDE - PAD * 2, top = y0 + 12;
        if (tab == 2) {
            int colW = (cw - 8) / 2;
            for (int i = 0; i < Theme.PRESETS.length; i++) {
                int bx = cx + (i % 2) * (colW + 8), by = top + 18 + (i / 2) * 25;
                if (Ctl.in(mx, my, bx, by, colW, 22)) {
                    c.themeIndex = i; c.useCustomTheme = false; HudConfig.save(); return true;
                }
            }
            int cy = top + 18 + (Theme.PRESETS.length / 2) * 25 + 6;
            if (pickHue(mx, my, cx, cy + 12, cw, true) || pickHue(mx, my, cx, cy + 30, cw, false)) return true;
            return super.mouseClicked(event, doubleClick);
        }
        List<Ctl> list = pages.get(tab);
        int y = top - Math.round(scroll);
        for (Ctl ctl : list) {
            if (my >= top && my < y0 + H - 12 && ctl.click(cx, y, cw, mx, my)) {
                dragging = ctl; dragX = cx; dragW = cw; return true;
            }
            y += ctl.h;
        }
        HudConfig.save();
        return super.mouseClicked(event, doubleClick);
    }

    private boolean pickHue(int mx, int my, int x, int y, int w, boolean first) {
        int bx = x + 50, bw = w - 50 - 24;
        if (!Ctl.in(mx, my, bx, y - 2, bw, 16)) return false;
        float h = Math.max(0f, Math.min(1f, (mx - bx) / (float) bw));
        int rgb = Color.HSBtoRGB(h, 0.75f, 1f) & 0xFFFFFF;
        HudConfig c = HudConfig.get();
        if (first) c.customColor1 = rgb; else c.customColor2 = rgb;
        c.useCustomTheme = true;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        int mx = (int) event.x(), my = (int) event.y();
        if (dragging != null) { dragging.drag(dragX, dragW, mx); return true; }
        if (tab == 2) {
            int cx = x0 + SIDE + PAD, cw = W - SIDE - PAD * 2, top = y0 + 12;
            int cy = top + 18 + (Theme.PRESETS.length / 2) * 25 + 6;
            if (pickHue(mx, my, cx, cy + 12, cw, true) || pickHue(mx, my, cx, cy + 30, cw, false)) return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        HudConfig.save();
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) sy * 14;
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        HudConfig.save();
        super.onClose();
    }
}
