package dev.prettyhud.mixin;

import dev.prettyhud.fx.Effects;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Обводка (glow) только у сущности, на которую ты сейчас навёл прицел.
 * Берётся стандартная цель прицела игры (crosshairPickEntity): сквозь блоки она не выбирается,
 * поэтому подсветки через стены нет. Эффект виден только тебе, серверу ничего не отправляется.
 */
@Mixin(Entity.class)
public abstract class EntityGlowMixin {

    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true)
    private void prettyhud$glowTarget(CallbackInfoReturnable<Boolean> cir) {
        if (Effects.isCrosshairTarget((Entity) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void prettyhud$glowColor(CallbackInfoReturnable<Integer> cir) {
        if (Effects.isCrosshairTarget((Entity) (Object) this)) {
            cir.setReturnValue(Effects.outlineColor());
        }
    }
}
