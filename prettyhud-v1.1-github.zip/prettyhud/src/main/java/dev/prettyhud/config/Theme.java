package dev.prettyhud.config;

/** Цветовая тема: два цвета (основной акцент и дополнительный), ARGB без альфы. */
public record Theme(String name, String description, int primary, int secondary) {

    public static final Theme[] PRESETS = {
            new Theme("Lunaris Blue", "Неоновый синий акцент", 0x4C7DFF, 0x6FA0FF),
            new Theme("Royal Violet", "Аметистовый фиолетовый", 0x8E5BFF, 0xB58CFF),
            new Theme("Ocean Cyan", "Морской аквамарин", 0x18D8FF, 0x7BEBFF),
            new Theme("Emerald Forest", "Неоновый изумрудный", 0x19E58A, 0x6DF2B4),
            new Theme("Sunset Ember", "Тёплый закатный янтарь", 0xFF6A2B, 0xFF9A3C),
            new Theme("Crimson Red", "Рубиновый кроваво-красный", 0xFF4057, 0xFF7A88),
            new Theme("Sakura Rose", "Пастельная сакура", 0xFF6B8F, 0xFFA3B8),
            new Theme("Cyber Neon", "Киберпанк маджента", 0xFF3FA4, 0x2FD8FF),
            new Theme("Golden Amber", "Сияющий золотой янтарь", 0xFFB81F, 0xFFD966),
            new Theme("Steel Slate", "Строгий серебряный", 0xAAB4C4, 0xD5DBE6),
            new Theme("Toxic Lime", "Ядовитый лайм", 0xA6F02B, 0xD0FF6B),
            new Theme("Soft Lavender", "Нежная лаванда", 0xC59BFF, 0xE0C8FF),
            new Theme("Blood Wine", "Винно-бордовый", 0xB0171F, 0xD8444C),
            new Theme("Ice Mint", "Ледяная мята", 0x39D9C0, 0x8BEBDB),
    };

    public static Theme custom(int c1, int c2) {
        return new Theme("Своя тема", "Палитра 2-х цветов", c1 & 0xFFFFFF, c2 & 0xFFFFFF);
    }

    /** Применяет альфу (0..1) к RGB и возвращает ARGB. */
    public static int argb(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (r << 16) | (g << 8) | b;
    }
}
