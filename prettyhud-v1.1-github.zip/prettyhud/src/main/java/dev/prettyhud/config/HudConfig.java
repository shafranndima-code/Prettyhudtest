package dev.prettyhud.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Все настройки мода. Хранится в config/prettyhud.json. */
public class HudConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("prettyhud.json");
    private static HudConfig instance = new HudConfig();

    public static HudConfig get() { return instance; }

    // ---- тема ----
    public int themeIndex = 4;          // Sunset Ember
    public boolean useCustomTheme = false;
    public int customColor1 = 0x8E5BFF;
    public int customColor2 = 0xB58CFF;

    // ---- общие ----
    public boolean shadows = true;
    public boolean glow = true;
    public float opacity = 1.0f;
    public float scale = 1.0f;

    // ---- виджеты (x, y — в пикселях GUI от левого верхнего угла) ----
    public Widget potions = new Widget(true, 8, 60);
    public Widget stats = new Widget(true, 8, 8);
    public Widget armor = new Widget(true, -1, -1);   // -1 = привязать к правому краю

    public boolean statsShowFps = true;
    public boolean statsShowPing = true;
    public boolean armorShowDurability = true;
    public int potionWarnSeconds = 10;

    // ---- эффекты ----
    public boolean halo = true;
    public int haloColorMode = 0;       // 0 = цвет темы
    public float haloHeight = 0.35f;
    public float haloRadius = 0.28f;
    public boolean haloForSelfInThirdPerson = true;
    public boolean haloForOthers = false;
    public boolean haloSparkles = true;

    public boolean skyParticles = true;
    public int skyParticleType = 0;     // 0 = звёзды, 1 = снег, 2 = светлячки, 3 = цвет темы, 4 = падающие звёзды
    public int skyParticleDensity = 3;  // 1..10, частиц за тик
    public int skyParticleHeight = 18;

    public boolean targetOutline = true;   // только цель под прицелом
    public boolean targetOutlineOnlyPlayers = false;
    public boolean targetPulse = true;     // обводка плавно меняет цвет
    public boolean targetRing = true;      // светящееся кольцо под целью

    public static class Widget {
        public boolean enabled;
        public int x, y;
        public Widget() {}
        public Widget(boolean enabled, int x, int y) { this.enabled = enabled; this.x = x; this.y = y; }
    }

    public Theme theme() {
        if (useCustomTheme) return Theme.custom(customColor1, customColor2);
        int i = Math.floorMod(themeIndex, Theme.PRESETS.length);
        return Theme.PRESETS[i];
    }

    public static void load() {
        if (!Files.exists(FILE)) { save(); return; }
        try (Reader r = Files.newBufferedReader(FILE)) {
            HudConfig loaded = GSON.fromJson(r, HudConfig.class);
            if (loaded != null) instance = loaded;
        } catch (Exception e) {
            // битый конфиг — оставляем значения по умолчанию, не падаем
            System.err.println("[PrettyHUD] Не удалось прочитать конфиг, использую значения по умолчанию: " + e);
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer w = Files.newBufferedWriter(FILE)) { GSON.toJson(instance, w); }
        } catch (IOException e) {
            System.err.println("[PrettyHUD] Не удалось сохранить конфиг: " + e);
        }
    }
}
