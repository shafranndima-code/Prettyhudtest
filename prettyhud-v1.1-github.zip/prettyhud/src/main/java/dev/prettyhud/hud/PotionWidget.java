package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Компактная плашка зелий: «Название II … 0:57». Не растягивается на весь экран. */
public class PotionWidget extends HudWidget {
    private static final int ROW_H = 13;
    private static final int PAD = 5;
    private static final int HEADER_H = 14;

    private record Row(String name, String time, int color, boolean warn) {}

    private final List<Row> rows = new ArrayList<>();
    private int nameW, timeW;

    public PotionWidget() { super("potions", "Зелья"); }

    @Override public HudConfig.Widget settings(HudConfig c) { return c.potions; }

    @Override
    public boolean measure(Minecraft mc) {
        rows.clear();
        if (mc.player == null) return false;
        HudConfig cfg = HudConfig.get();
        List<MobEffectInstance> effects = new ArrayList<>(mc.player.getActiveEffects());
        if (effects.isEmpty()) return false;
        effects.sort(Comparator.comparingInt(MobEffectInstance::getDuration).reversed());
        for (MobEffectInstance e : effects) {
            String name = e.getEffect().value().getDisplayName().getString();
            if (e.getAmplifier() > 0) name += " " + roman(e.getAmplifier() + 1);
            boolean inf = e.isInfiniteDuration();
            int secs = inf ? -1 : e.getDuration() / 20;
            String time = inf ? "∞" : (secs / 60) + ":" + (secs % 60 < 10 ? "0" : "") + (secs % 60);
            boolean warn = !inf && secs <= cfg.potionWarnSeconds;
            rows.add(new Row(name, time, e.getEffect().value().getColor(), warn));
        }
        return layout(mc.font);
    }

    @Override
    public boolean measureForEditor(Minecraft mc) {
        rows.clear();
        rows.add(new Row("Сила II", "0:57", 0xFF6A2B, false));
        rows.add(new Row("Скорость", "3:12", 0x7CAFC6, false));
        rows.add(new Row("Огнестойкость", "0:08", 0xE49A3A, true));
        return layout(mc.font);
    }

    private boolean layout(Font font) {
        nameW = 0; timeW = 0;
        for (Row r : rows) {
            nameW = Math.max(nameW, font.width(r.name));
            timeW = Math.max(timeW, font.width(r.time));
        }
        nameW = Math.max(nameW, font.width("Potions"));
        width = PAD + 4 + nameW + 12 + timeW + PAD;
        height = HEADER_H + rows.size() * ROW_H + 3;
        return true;
    }

    @Override
    public void render(GuiGraphics g, Minecraft mc) {
        Theme t = HudConfig.get().theme();
        Font font = mc.font;
        Draw.panel(g, 0, 0, width, height, t);
        g.drawString(font, "Potions", PAD, 4, Draw.a(t.primary(), 1f), false);
        g.fill(PAD, HEADER_H - 1, width - PAD, HEADER_H, Draw.a(0xFFFFFF, 0.08f));

        int y = HEADER_H + 2;
        for (Row r : rows) {
            int accent = r.warn ? 0xFF4057 : r.color;
            g.fill(PAD, y + 1, PAD + 2, y + ROW_H - 3, Draw.a(accent, 1f));
            g.drawString(font, r.name, PAD + 6, y + 1, Draw.text(1f), false);
            int tc = r.warn ? Draw.a(0xFF6B7A, 1f) : Draw.text(0.75f);
            g.drawString(font, r.time, width - PAD - font.width(r.time), y + 1, tc, false);
            y += ROW_H;
        }
    }

    private static String roman(int n) {
        return switch (n) {
            case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V";
            case 6 -> "VI"; case 7 -> "VII"; case 8 -> "VIII"; case 9 -> "IX"; case 10 -> "X";
            default -> String.valueOf(n);
        };
    }
}
