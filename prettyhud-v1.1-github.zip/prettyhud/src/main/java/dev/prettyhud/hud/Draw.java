package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.minecraft.client.gui.GuiGraphics;

/** Небольшие примитивы рисования: скруглённые панели, свечение, акцентная линия. Только fill() — дёшево по FPS. */
public final class Draw {
    private Draw() {}

    public static final int BG = 0x0B0F1A;      // тёмный фон панелей
    public static final int BG_LIGHT = 0x151B2B;
    public static final int TEXT = 0xFFFFFF;
    public static final int TEXT_DIM = 0x9AA3B5;

    /** Скруглённый прямоугольник радиуса 2 px: центр + боковые полосы без угловых пикселей. */
    public static void roundRect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x + 2, y, x + w - 2, y + h, argb);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, argb);
        g.fill(x, y + 2, x + w, y + h - 2, argb);
    }

    /** Панель виджета: фон, лёгкое свечение цвета темы и акцентная линия сверху. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, Theme t) {
        HudConfig c = HudConfig.get();
        float o = c.opacity;
        if (c.glow) {
            roundRect(g, x - 2, y - 2, w + 4, h + 4, Theme.argb(t.primary(), 0.10f * o));
            roundRect(g, x - 1, y - 1, w + 2, h + 2, Theme.argb(t.primary(), 0.16f * o));
        }
        if (c.shadows) roundRect(g, x + 1, y + 2, w, h, Theme.argb(0x000000, 0.35f * o));
        roundRect(g, x, y, w, h, Theme.argb(BG, 0.88f * o));
        g.fill(x + 2, y, x + w - 2, y + 1, Theme.argb(t.primary(), 0.95f * o));
    }

    public static int text(float alphaMul) {
        return Theme.argb(TEXT, HudConfig.get().opacity * alphaMul);
    }

    public static int a(int rgb, float alpha) {
        return Theme.argb(rgb, alpha * HudConfig.get().opacity);
    }
}
