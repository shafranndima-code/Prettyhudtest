package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;

/** Узкая плашка «● 64 fps | 0 ms». Строка пересобирается только при смене значений. */
public class StatsWidget extends HudWidget {
    private String text = "";
    private int lastFps = -1, lastPing = -2;
    private boolean lastShowFps, lastShowPing;

    public StatsWidget() { super("stats", "FPS / Пинг"); }

    @Override public HudConfig.Widget settings(HudConfig c) { return c.stats; }

    @Override
    public boolean measure(Minecraft mc) {
        HudConfig c = HudConfig.get();
        if (!c.statsShowFps && !c.statsShowPing) return false;
        int fps = mc.getFps();
        int ping = ping(mc);
        if (fps != lastFps || ping != lastPing || c.statsShowFps != lastShowFps || c.statsShowPing != lastShowPing) {
            lastFps = fps; lastPing = ping;
            lastShowFps = c.statsShowFps; lastShowPing = c.statsShowPing;
            StringBuilder sb = new StringBuilder();
            if (c.statsShowFps) sb.append(fps).append(" fps");
            if (c.statsShowFps && c.statsShowPing) sb.append("  |  ");
            if (c.statsShowPing) sb.append(ping < 0 ? "— ms" : ping + " ms");
            text = sb.toString();
        }
        width = 8 + 8 + 4 + mc.font.width(text) + 8;
        height = 17;
        return true;
    }

    private static int ping(Minecraft mc) {
        if (mc.player == null || mc.getConnection() == null) return -1;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? -1 : info.getLatency();
    }

    @Override
    public void render(GuiGraphics g, Minecraft mc) {
        Theme t = HudConfig.get().theme();
        Font font = mc.font;
        Draw.panel(g, 0, 0, width, height, t);
        // маленький «логотип» — ромб из квадратов цвета темы
        g.fill(7, 6, 11, 10, Draw.a(t.primary(), 1f));
        g.fill(9, 8, 13, 12, Draw.a(t.secondary(), 0.9f));
        g.drawString(font, text, 8 + 8 + 4, 5, Draw.text(1f), false);
    }
}
