package dev.prettyhud.fx;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Чисто косметические клиентские эффекты: нимб, кольцо под целью, частицы в небе.
 * Всё через обычные частицы у тебя на экране — на сервер ничего не отправляется.
 */
public final class Effects {
    private static int tickCounter = 0;

    // состояние «падающей звезды»
    private static int shootLife = 0;
    private static double shootX, shootY, shootZ, shootVX, shootVY, shootVZ;

    private Effects() {}

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Effects::tick);
    }

    private static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        Player self = mc.player;
        if (level == null || self == null || mc.isPaused()) return;
        tickCounter++;
        HudConfig c = HudConfig.get();
        if (c.halo) halo(mc, level, self, c);
        if (c.skyParticles) sky(level, self, c);
        if (c.targetOutline && c.targetRing) targetRing(mc, level, c);
    }

    // ---------- общие помощники ----------

    /** Бегущий градиент между двумя цветами темы: phase 0..2π -> цвет. */
    private static int gradient(Theme t, double phase) {
        float k = (float) (0.5 + 0.5 * Math.sin(phase));
        return Theme.lerp(t.primary(), t.secondary(), k);
    }

    /** Подмешивает белый — для блика. */
    private static int whiten(int rgb, float amount) {
        return Theme.lerp(rgb, 0xFFFFFF, amount);
    }

    // ---------- нимб ----------

    private static void halo(Minecraft mc, ClientLevel level, Player self, HudConfig c) {
        // обновляем раз в 2 тика: частицы живут дольше, кольцо выглядит цельным
        if ((tickCounter & 1) != 0) return;

        boolean firstPerson = mc.options.getCameraType().isFirstPerson();
        if (c.haloForSelfInThirdPerson && !firstPerson) haloRing(level, self, c);
        if (c.haloForOthers) {
            for (Player p : level.players()) {
                if (p != self && p.distanceToSqr(self) < 48 * 48) haloRing(level, p, c);
            }
        }
    }

    private static void haloRing(ClientLevel level, Player p, HudConfig c) {
        Theme t = c.theme();
        RandomSource r = level.getRandom();

        // лёгкое «дыхание»: нимб чуть покачивается вверх-вниз
        double bob = Math.sin(tickCounter * 0.09) * 0.025;
        double cx = p.getX();
        double cz = p.getZ();
        double cy = p.getY() + p.getBbHeight() + c.haloHeight + bob;

        int points = 28;
        double shimmer = tickCounter * 0.16;
        for (int i = 0; i < points; i++) {
            double a = i * (Math.PI * 2 / points);
            // два оборота градиента по кольцу, он крутится со временем
            int col = gradient(t, a * 2 + shimmer);
            // бегущий блик: яркая «искра» обходит кольцо по кругу
            double d = Math.abs(Math.IEEEremainder(a - shimmer * 0.7, Math.PI * 2)); // угловое расстояние до блика
            if (d < 0.5) col = whiten(col, (float) (1.0 - d / 0.5) * 0.65f);
            level.addParticle(new DustParticleOptions(col, 0.42f),
                    cx + Math.cos(a) * c.haloRadius, cy, cz + Math.sin(a) * c.haloRadius, 0, 0, 0);
        }

        // тонкое внутреннее кольцо — даёт ощущение объёма и свечения
        int inner = 14;
        for (int i = 0; i < inner; i++) {
            double a = i * (Math.PI * 2 / inner) + 0.11;
            level.addParticle(new DustParticleOptions(whiten(gradient(t, a * 2 + shimmer), 0.35f), 0.26f),
                    cx + Math.cos(a) * c.haloRadius * 0.82, cy, cz + Math.sin(a) * c.haloRadius * 0.82, 0, 0, 0);
        }

        // искорки, медленно уплывающие вверх от нимба
        if (c.haloSparkles && r.nextInt(3) == 0) {
            double a = r.nextDouble() * Math.PI * 2;
            double x = cx + Math.cos(a) * c.haloRadius;
            double z = cz + Math.sin(a) * c.haloRadius;
            if (r.nextBoolean()) {
                level.addParticle(ParticleTypes.END_ROD, x, cy, z, 0, 0.012, 0);
            } else {
                level.addParticle(new DustColorTransitionOptions(t.primary(), t.secondary(), 0.55f),
                        x, cy, z, (r.nextDouble() - 0.5) * 0.01, 0.015, (r.nextDouble() - 0.5) * 0.01);
            }
        }
    }

    // ---------- кольцо под целью ----------

    private static void targetRing(Minecraft mc, ClientLevel level, HudConfig c) {
        if ((tickCounter & 1) != 0) return;
        Entity e = mc.crosshairPickEntity;
        if (e == null || !isCrosshairTarget(e)) return;

        Theme t = c.theme();
        RandomSource r = level.getRandom();
        double radius = Math.max(0.45, e.getBbWidth() * 0.75 + 0.15);
        double pulse = 1.0 + 0.06 * Math.sin(tickCounter * 0.25);
        double y = e.getY() + 0.06;
        int points = 22;
        double spin = tickCounter * 0.07;

        for (int i = 0; i < points; i++) {
            double a = spin + i * (Math.PI * 2 / points);
            int col = gradient(t, a * 3 + tickCounter * 0.18);
            level.addParticle(new DustParticleOptions(col, 0.5f),
                    e.getX() + Math.cos(a) * radius * pulse, y, e.getZ() + Math.sin(a) * radius * pulse, 0, 0, 0);
        }
        // две «искры» вылетают вверх вдоль тела цели
        for (int i = 0; i < 2; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            level.addParticle(new DustColorTransitionOptions(t.primary(), t.secondary(), 0.6f),
                    e.getX() + Math.cos(a) * radius, y, e.getZ() + Math.sin(a) * radius,
                    0, 0.04 + r.nextDouble() * 0.03, 0);
        }
    }

    // ---------- частицы в небе ----------

    private static void sky(ClientLevel level, Player self, HudConfig c) {
        // не тратим частицы под землёй и в помещениях
        if (!level.canSeeSky(BlockPos.containing(self.getX(), self.getEyeY(), self.getZ()))) return;

        Theme t = c.theme();
        RandomSource r = level.getRandom();
        int n = Math.max(1, Math.min(10, c.skyParticleDensity));

        if (c.skyParticleType == 4) { // падающие звёзды
            shootingStar(level, self, c, t, r, n);
            return;
        }

        for (int i = 0; i < n; i++) {
            // купол: ближе к краям выше всего, над головой тоже есть частицы
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 3 + r.nextDouble() * 26;
            double x = self.getX() + Math.cos(ang) * dist;
            double z = self.getZ() + Math.sin(ang) * dist;
            double y = self.getY() + c.skyParticleHeight * (0.55 + r.nextDouble() * 0.9);
            double sway = Math.sin(tickCounter * 0.04 + ang * 3) * 0.006; // мягкий боковой дрейф

            switch (c.skyParticleType) {
                case 1 -> level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, sway, -0.04, sway * 0.7);
                case 2 -> level.addParticle(ParticleTypes.GLOW, x, y - c.skyParticleHeight * 0.7, z,
                        (r.nextDouble() - 0.5) * 0.012, 0.004 + r.nextDouble() * 0.004, (r.nextDouble() - 0.5) * 0.012);
                case 3 -> level.addParticle(
                        new DustColorTransitionOptions(t.primary(), t.secondary(), 0.7f + r.nextFloat() * 0.5f),
                        x, y, z, sway, -0.02, sway * 0.7);
                default -> { // звёзды: белые искры + цветные блёстки темы
                    if (r.nextInt(10) < 7) {
                        level.addParticle(ParticleTypes.END_ROD, x, y, z, sway, -0.008, sway);
                    } else {
                        level.addParticle(new DustColorTransitionOptions(t.primary(), whiten(t.secondary(), 0.4f), 0.8f),
                                x, y, z, sway, -0.012, sway);
                    }
                }
            }
        }
    }

    private static void shootingStar(ClientLevel level, Player self, HudConfig c, Theme t, RandomSource r, int density) {
        if (shootLife <= 0) {
            // шанс запуска растёт с плотностью: ~ раз в 3–10 секунд
            if (r.nextFloat() < density * 0.0045f) {
                double ang = r.nextDouble() * Math.PI * 2;
                double dist = 18 + r.nextDouble() * 18;
                shootX = self.getX() + Math.cos(ang) * dist;
                shootZ = self.getZ() + Math.sin(ang) * dist;
                shootY = self.getY() + c.skyParticleHeight + 6 + r.nextDouble() * 10;
                double dir = ang + Math.PI / 2 + (r.nextDouble() - 0.5) * 0.6; // летит по касательной
                double speed = 1.1 + r.nextDouble() * 0.6;
                shootVX = Math.cos(dir) * speed;
                shootVZ = Math.sin(dir) * speed;
                shootVY = -0.35 - r.nextDouble() * 0.25;
                shootLife = 22;
            }
            return;
        }
        shootLife--;
        shootX += shootVX;
        shootY += shootVY;
        shootZ += shootVZ;
        // яркая голова + цветной шлейф, который тает
        level.addParticle(ParticleTypes.END_ROD, shootX, shootY, shootZ, 0, 0, 0);
        for (int i = 1; i <= 3; i++) {
            level.addParticle(new DustColorTransitionOptions(t.primary(), t.secondary(), 0.9f - i * 0.15f),
                    shootX - shootVX * i * 0.3, shootY - shootVY * i * 0.3, shootZ - shootVZ * i * 0.3, 0, 0, 0);
        }
    }

    // ---------- подсветка цели под прицелом ----------

    /** Истина, если эта сущность прямо сейчас под прицелом и подсветка включена. */
    public static boolean isCrosshairTarget(Entity e) {
        HudConfig c = HudConfig.get();
        if (!c.targetOutline) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || e.level() != mc.level) return false;
        Entity target = mc.crosshairPickEntity;
        if (target == null || target != e) return false;
        return !c.targetOutlineOnlyPlayers || e instanceof Player;
    }

    /** Цвет обводки цели: плавно перетекает между двумя цветами темы (или статичный). */
    public static int outlineColor() {
        HudConfig c = HudConfig.get();
        Theme t = c.theme();
        if (!c.targetPulse) return t.primary();
        double phase = (System.currentTimeMillis() % 100000L) / 1000.0 * 3.2;
        return gradient(t, phase);
    }
}
